---
name: newsletter-publisher
description: 週次で Newsletter コンテンツを生成・配信。Mailchimp API 経由で自動送信。
---

## 🎯 ミッション

週に1回、価値あるコンテンツを自動生成して Newsletter 配信する。読者にインサイト・学び・気づきを提供。

## ⚙️ 動作フロー

```
1. テーマ決定
   - 最近のトレンド（web_search）
   - ユーザーレビューの傾向
   - Anicca の哲学（無常・compassion）
   
2. リサーチ
   - web_search で関連記事を検索
   - web_fetch で深掘り
   - 引用元を記録
   
3. コンテンツ生成
   - Hook（読者を引き込む）
   - 本文（2000-3000 words）
   - 具体例・ストーリー
   - Actionable takeaway
   
4. HTML フォーマット
   - レスポンシブデザイン
   - 読みやすいタイポグラフィ
   - Anicca ブランドカラー (#6B4EFF)
   
5. Mailchimp API で配信
   - Campaign 作成
   - Content 設定
   - Schedule or Send
   
6. メトリクス収集（配信後24h）
   - 開封率
   - クリック率
   - Slack #ops に報告
```

## 📋 環境変数

- `MAILCHIMP_API_KEY` — Mailchimp API Key (format: {key}-{server_prefix})
- `MAILCHIMP_SERVER_PREFIX` — Server prefix (e.g., us5)
- `MAILCHIMP_LIST_ID` — Audience List ID (default: 2a302dc906)

## 🔧 実装

### Mailchimp API 認証

```python
import base64

api_key = os.environ['MAILCHIMP_API_KEY']
server_prefix = os.environ['MAILCHIMP_SERVER_PREFIX']

auth = base64.b64encode(f'anystring:{api_key}'.encode()).decode()
headers = {
    "Authorization": f"Basic {auth}",
    "Content-Type": "application/json"
}
```

### Campaign 作成

```bash
curl -sf --max-time 30 \
  -X POST "https://{server_prefix}.api.mailchimp.com/3.0/campaigns" \
  -u "anystring:{api_key}" \
  -H "Content-Type: application/json" \
  -d '{
    "type": "regular",
    "recipients": {
      "list_id": "{list_id}"
    },
    "settings": {
      "subject_line": "{subject}",
      "title": "{title}",
      "from_name": "Anicca",
      "reply_to": "keiodaisuke@gmail.com"
    }
  }'
```

### Content 設定

```bash
curl -sf --max-time 30 \
  -X PUT "https://{server_prefix}.api.mailchimp.com/3.0/campaigns/{campaign_id}/content" \
  -u "anystring:{api_key}" \
  -H "Content-Type: application/json" \
  -d '{
    "html": "{html_content}"
  }'
```

### 送信

```bash
curl -sf --max-time 30 \
  -X POST "https://{server_prefix}.api.mailchimp.com/3.0/campaigns/{campaign_id}/actions/send" \
  -u "anystring:{api_key}"
```

### メトリクス取得（配信後）

```bash
curl -sf --max-time 30 \
  "https://{server_prefix}.api.mailchimp.com/3.0/reports/{campaign_id}" \
  -u "anystring:{api_key}"
```

## 📝 コンテンツテンプレート

### HTML 構造

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            line-height: 1.8;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
        }
        h1 {
            color: #6B4EFF;
            border-bottom: 3px solid #6B4EFF;
            padding-bottom: 10px;
            font-size: 28px;
        }
        h2 {
            color: #333;
            margin-top: 30px;
            font-size: 22px;
        }
        h3 {
            color: #555;
            margin-top: 20px;
            font-size: 18px;
        }
        .intro {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .quote {
            border-left: 4px solid #6B4EFF;
            padding-left: 20px;
            margin: 20px 0;
            font-style: italic;
            color: #555;
        }
        .highlight {
            background: #fff3cd;
            padding: 2px 6px;
            border-radius: 3px;
        }
        .cta {
            background: #6B4EFF;
            color: white;
            padding: 15px 30px;
            text-align: center;
            border-radius: 8px;
            margin: 30px 0;
            text-decoration: none;
            display: inline-block;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 0.9em;
            color: #666;
        }
        ul, ol {
            margin: 15px 0;
            padding-left: 25px;
        }
        li {
            margin: 8px 0;
        }
    </style>
</head>
<body>
    <h1>🧘 {Title}</h1>
    
    <div class="intro">
        {Hook - 読者を引き込む短い導入}
    </div>
    
    <h2>{Section 1 Title}</h2>
    <p>{Content}</p>
    
    <div class="quote">
        <p>"{引用またはキーメッセージ}"</p>
    </div>
    
    <h2>{Section 2 Title}</h2>
    <p>{Content}</p>
    
    <h3>{Subsection Title}</h3>
    <ul>
        <li>{Point 1}</li>
        <li>{Point 2}</li>
        <li>{Point 3}</li>
    </ul>
    
    <h2>💡 Takeaway</h2>
    <p>{Actionable advice - 読者が今日から実践できること}</p>
    
    <div class="footer">
        <p>このニュースレターは Anicca (AI Agent) によって執筆・配信されました。</p>
        <p>🧘 <em>Anicca</em> — パーリ語で「無常（impermanence）」</p>
        <p><a href="https://anicca.ai">anicca.ai</a> | <a href="*|UNSUB|*">配信停止</a></p>
    </div>
</body>
</html>
```

## 🎨 コンテンツガイドライン

### トーン
- **共感的で非批判的**
- **実践的で actionable**
- **深掘りするが難解すぎない**
- **ストーリーテリングを活用**

### 構成
1. **Hook** (100-200 words) — 読者の注意を引く
2. **Context** (300-500 words) — 背景・問題提起
3. **Insight** (800-1200 words) — 核心的な洞察・分析
4. **Examples** (400-600 words) — 具体例・ケーススタディ
5. **Takeaway** (200-300 words) — 実践的なアドバイス

### 引用ルール
- 必ず出典を明記
- リンクを含める
- 信頼できるソース（学術論文、権威あるメディア）を優先

## 📊 Slack 通知フォーマット

### 配信完了通知

```
📧 Newsletter Sent!

Subject: {subject_line}
Recipients: {recipient_count}
Campaign ID: {campaign_id}

📅 Sent: {timestamp}
🔗 View: https://us5.admin.mailchimp.com/campaigns/show?id={web_id}
```

### メトリクスレポート（24h後）

```
📊 Newsletter Metrics (24h)

Subject: {subject_line}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📨 Emails Sent: {emails_sent}
📬 Delivered: {delivered} ({delivery_rate}%)
📂 Opened: {opens} ({open_rate}%)
🖱️ Clicked: {clicks} ({click_rate}%)

Top Links:
1. {link_1} — {clicks_1} clicks
2. {link_2} — {clicks_2} clicks
3. {link_3} — {clicks_3} clicks

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Campaign ID: {campaign_id}
```

## ⏰ Cron スケジュール

週1回（日曜 18:00 JST） — 月曜朝に配信

```yaml
schedule:
  kind: cron
  expr: "0 18 * * 0"  # 日曜 18:00 JST
  tz: Asia/Tokyo

payload:
  kind: agentTurn
  message: "Generate and send weekly newsletter. Use newsletter-publisher skill. Research trending topics, write compelling content (2000-3000 words), and send via Mailchimp."
  timeoutSeconds: 600

sessionTarget: isolated

delivery:
  mode: announce
  channel: slack
  to: C091G3PKHL2  # #metrics
```

## 🧪 テスト

### テスト送信（本番 List を使わない）

```bash
# テストメール送信
curl -sf --max-time 30 \
  -X POST "https://us5.api.mailchimp.com/3.0/campaigns/{campaign_id}/actions/test" \
  -u "anystring:{api_key}" \
  -H "Content-Type: application/json" \
  -d '{
    "test_emails": ["keiodaisuke@gmail.com"],
    "send_type": "html"
  }'
```

### 手動実行

```bash
openclaw exec "Generate and send newsletter using newsletter-publisher skill"
```

## 📝 注意事項

- Mailchimp Free Plan: 500 contacts, 1000 sends/month
- HTML メールサイズ制限: 最大 1MB
- 配信後の編集・削除は不可
- スパムフィルタ回避のため、from_email は認証済みドメインを推奨
- Unsubscribe リンク (`*|UNSUB|*`) は必須

## 🚀 今後の拡張

- A/B テスト（Subject line）
- パーソナライゼーション（Merge tags: `*|FNAME|*`）
- セグメント配信（Trial users, Active users, etc.）
- RSS-to-Email（ブログ記事の自動配信）
