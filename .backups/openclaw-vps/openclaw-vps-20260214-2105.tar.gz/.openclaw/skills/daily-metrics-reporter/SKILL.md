---
name: daily-metrics-reporter
description: Anicca 日次メトリクスを Slack #metrics に投稿（直近1週間のASC+MP、RCは現況）
---

## ⚠️ 重要ルール（絶対厳守）

- ユーザーに確認を求めない（即座に取得→投稿）
- `revenuecat` / `mixpanel` / `asc` の架空コマンドは使わない
- 使ってよい実行は **`exec` のみ**（中で `curl` と `openclaw message send` を使用）
- 値をハードコードしない。必ずAPIレスポンスから算出する

---

## 期間の方針（固定）

- **Mixpanel / App Store Connect:** 直近 **7日**（今日含む）
  - `from_date = today - 6 days`
  - `to_date = today`
- **RevenueCat:** v2 `/metrics/overview` を使用
  - `MRR` は現況（RevenueCatが定義する P28D MRR）
  - `Revenue (28d)` も併記（overviewの `revenue`）

---

## 取得する指標（Narita-san 要望に合わせて最小化）

### ✅ App Store Connect（直近7日）
- Downloads
- Downloads by country（国別内訳: `JAPAN (JP): 12` のように **国名+ISOコード**で出す）

### ✅ RevenueCat（overview）
- MRR ($)
- Revenue (28d, $)
- Active Subscriptions
- Active Trials

### ✅ Mixpanel（直近7日合計）
- onboarding_started
- onboarding_paywall_viewed
- rc_trial_started_event

※ `first_app_opened` と `rc_initial_purchase_event` は **出力しない**。

---

## App Store Connect（VPS 直接 API アクセス）

ASC は失敗しがちなので **失敗してもレポートは投稿**する（N/A を出す）。

### 必要な環境変数
- `ASC_KEY_ID` — App Store Connect API キー ID
- `ASC_ISSUER_ID` — Issuer ID
- `~/.keys/AuthKey_<KEY_ID>.p8` — プライベートキーファイル

### 取得ロジック（Python）— 完全動作版

```python
import jwt, time, os, json, gzip, urllib.request
from datetime import datetime, timedelta

def get_asc_downloads(days=7):
    """直近N日間の Downloads を取得（国別内訳付き）"""
    
    # 環境変数から認証情報
    key_id = os.environ.get('ASC_KEY_ID')
    issuer_id = os.environ.get('ASC_ISSUER_ID')
    vendor_number = os.environ.get('ASC_VENDOR_NUMBER')
    key_path = os.path.expanduser(f'~/.keys/AuthKey_{key_id}.p8')
    
    with open(key_path) as f:
        pk = f.read()
    
    # JWT 生成
    token = jwt.encode(
        {
            "iss": issuer_id,
            "iat": int(time.time()),
            "exp": int(time.time()) + 1200,
            "aud": "appstoreconnect-v1"
        },
        pk,
        algorithm="ES256",
        headers={"alg": "ES256", "kid": key_id, "typ": "JWT"}
    )
    
    total_units = 0
    by_country = {}
    
    # 直近N日分を取得（1日ずつ）
    for i in range(2, days + 2):  # 2日前から（当日・前日はデータなし）
        report_date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
        url = f"https://api.appstoreconnect.apple.com/v1/salesReports?filter[reportType]=SALES&filter[reportSubType]=SUMMARY&filter[frequency]=DAILY&filter[vendorNumber]={vendor_number}&filter[reportDate]={report_date}"
        
        req = urllib.request.Request(url)
        req.add_header("Authorization", f"Bearer {token}")
        req.add_header("Accept", "application/a-gzip")  # 重要: a-gzip（ハイフン）
        
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = gzip.decompress(resp.read()).decode('utf-8')
                lines = data.strip().split('\n')
                
                for line in lines[1:]:  # ヘッダーをスキップ
                    cols = line.split('\t')
                    if len(cols) > 12:
                        units = int(cols[7]) if cols[7].lstrip('-').isdigit() else 0
                        country = cols[12]
                        total_units += units
                        by_country[country] = by_country.get(country, 0) + units
        except:
            pass  # その日のデータがない場合はスキップ
    
    return {"total": total_units, "by_country": by_country}

# 使用例
result = get_asc_downloads(7)
print(f"Downloads: {result['total']}")
print(f"By Country: {result['by_country']}")
```

### 実行例

```bash
python3 << 'PY'
import jwt, time, os, json, gzip, urllib.request
from datetime import datetime, timedelta

key_id = os.environ.get('ASC_KEY_ID')
issuer_id = os.environ.get('ASC_ISSUER_ID')
vendor_number = os.environ.get('ASC_VENDOR_NUMBER')

with open(os.path.expanduser(f'~/.keys/AuthKey_{key_id}.p8')) as f:
    pk = f.read()

token = jwt.encode(
    {"iss": issuer_id, "iat": int(time.time()), "exp": int(time.time()) + 1200, "aud": "appstoreconnect-v1"},
    pk, algorithm="ES256", headers={"alg": "ES256", "kid": key_id, "typ": "JWT"}
)

total = 0
by_country = {}

for i in range(2, 9):
    d = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
    url = f"https://api.appstoreconnect.apple.com/v1/salesReports?filter[reportType]=SALES&filter[reportSubType]=SUMMARY&filter[frequency]=DAILY&filter[vendorNumber]={vendor_number}&filter[reportDate]={d}"
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/a-gzip")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = gzip.decompress(resp.read()).decode('utf-8')
            for line in data.strip().split('\n')[1:]:
                cols = line.split('\t')
                if len(cols) > 12:
                    u = int(cols[7]) if cols[7].lstrip('-').isdigit() else 0
                    c = cols[12]
                    total += u
                    by_country[c] = by_country.get(c, 0) + u
    except: pass

print(json.dumps({"total": total, "by_country": by_country}))
PY
# 出力例: {"total": 104, "by_country": {"JP": 95, "US": 5, "AU": 4}}
```

### 国名の表記ルール（固定）

- 表記は **`COUNTRY_NAME (CC)`**
  - 例: `JAPAN (JP)` / `UNITED STATES (US)`
- 国名は「ISOコード→英語国名」のマッピングで出す。
  - まずは最低限 `JP -> JAPAN` を保証。
  - その他は可能なら一般的な英語名に変換、難しければ `CC` のみでも可。

---

## Mixpanel API（events）

Basic Auth: `$MIXPANEL_API_SECRET:`

例（7日間のイベント合計を作る）：

```bash
from_date=$(date -v-6d +%Y-%m-%d)
to_date=$(date +%Y-%m-%d)

curl -sf --max-time 30 \
  "https://mixpanel.com/api/query/events?event=%5B%22onboarding_started%22%5D&type=general&unit=day&from_date=$from_date&to_date=$to_date&project_id=3970220" \
  -u "$MIXPANEL_API_SECRET:" -H "accept: application/json"
```

合計は `data.values.<eventName>` の日別値を合算する。

---

## RevenueCat API（overview）

```bash
curl -sf --max-time 30 \
  "https://api.revenuecat.com/v2/projects/projbb7b9d1b/metrics/overview" \
  -H "Authorization: Bearer $REVENUECAT_V2_SECRET_KEY" \
  -H "Content-Type: application/json"
```

---

## 変換率（直近7日）

- オンボ→Paywall = `onboarding_paywall_viewed / onboarding_started`
- Paywall→トライアル = `rc_trial_started_event / onboarding_paywall_viewed`
- オンボ→トライアル = `rc_trial_started_event / onboarding_started`

分母が0の場合は `NA`。

---

## 出力フォーマット（固定）

タイトルは必ずこれ：

`:bar_chart: Anicca Daily Report (YYYY-MM-DD) 1 Week`

本文：

```
:bar_chart: Anicca Daily Report (YYYY-MM-DD) 1 Week
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📱 APP STORE CONNECT (直近7日)
  Downloads: {downloads}
  Downloads by Country:
    - JAPAN (JP): {n}
    - UNITED STATES (US): {n}
    - ...

💰 REVENUECAT
  MRR: ${mrr}
  Revenue (28d): ${revenue_28d}
  Active Subscriptions: {active_subscriptions}
  Active Trials: {active_trials}

📈 FUNNEL (Mixpanel 直近7日合計)
  onboarding_started: {onboarding_started}
  onboarding_paywall_viewed: {onboarding_paywall_viewed}
  rc_trial_started_event: {trial_started} ← トライアル開始

📊 変換率
  オンボ→Paywall: {onboard_to_paywall}%
  Paywall→トライアル: {paywall_to_trial}%
  オンボ→トライアル: {onboard_to_trial}%

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧘 Anicca Metrics Bot
```

---

## 投稿先

Slack #metrics（C091G3PKHL2）

```bash
openclaw message send --channel slack --target "C091G3PKHL2" --message "{report_text}"
```
