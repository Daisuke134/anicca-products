---
name: mac-codex
description: Mac の Codex CLI を Tailscale SSH 経由でオーケストレーション。ChatGPT Pro の無制限 Codex を使用（追加 API 料金なし）。
---

# Mac Codex オーケストレーション

VPS から Mac の Codex CLI を SSH 経由で実行する。ChatGPT Pro サブスク内なので追加料金なし。

## 前提条件

- Tailscale が VPS と Mac の両方で `up` 状態
- Mac の IP: `100.108.140.123` (cbns03macbook-pro)
- SSH: `cbns03@100.108.140.123`
- Codex パス: `/opt/homebrew/bin/codex`

## 基本パターン

```bash
ssh cbns03@100.108.140.123 'export PATH="/opt/homebrew/bin:/opt/homebrew/opt/node/bin:$PATH" && cd /Users/cbns03/Downloads/anicca-project && /opt/homebrew/bin/codex exec --dangerously-bypass-approvals-and-sandbox "<PROMPT>"'
```

## 実行例

### ファイル作成
```bash
exec pty:true timeout:120 command:"ssh cbns03@100.108.140.123 'export PATH=\"/opt/homebrew/bin:$PATH\" && cd /Users/cbns03/Downloads/anicca-project && /opt/homebrew/bin/codex exec --dangerously-bypass-approvals-and-sandbox \"Create file at path/to/file.md with content: ...\"'"
```

### コード修正
```bash
exec pty:true timeout:300 command:"ssh cbns03@100.108.140.123 'export PATH=\"/opt/homebrew/bin:$PATH\" && cd /Users/cbns03/Downloads/anicca-project && /opt/homebrew/bin/codex exec --full-auto \"Fix the bug in src/api/nudge.ts where...\"'"
```

### バックグラウンド実行（長いタスク）
```bash
exec pty:true background:true timeout:600 command:"ssh cbns03@100.108.140.123 'export PATH=\"/opt/homebrew/bin:$PATH\" && cd /Users/cbns03/Downloads/anicca-project && /opt/homebrew/bin/codex exec --full-auto \"Implement the entire feature: ...\"'"
```

その後 `process action:poll sessionId:XXX` で進捗確認。

## フラグ

| フラグ | 効果 |
|--------|------|
| `exec "<prompt>"` | ワンショット実行、完了後終了 |
| `--full-auto` | サンドボックス内で自動承認 |
| `--dangerously-bypass-approvals-and-sandbox` | 承認なし、サンドボックスなし（最速） |

## 注意点

1. **MCP サーバー起動に 30-60 秒かかる** — 初回は遅い
2. **PATH を明示的に設定** — SSH 環境では PATH が通っていない
3. **timeout を長めに** — MCP 起動時間 + 実行時間
4. **pty:true 必須** — インタラクティブ CLI なので

## 料金

**無料（ChatGPT Pro サブスクの一部）**

Mac の Codex CLI は `~/.codex/auth.json` の認証を使用。これは ChatGPT Pro の Codex 無制限枠。VPS から SSH で呼び出しても Mac 上で実行されるので、追加の OpenAI API 料金は発生しない。

## トラブルシューティング

### `command not found: codex`
→ PATH が通っていない。フルパス `/opt/homebrew/bin/codex` を使う。

### `env: node: No such file or directory`
→ Node の PATH も必要: `export PATH="/opt/homebrew/bin:/opt/homebrew/opt/node/bin:$PATH"`

### タイムアウト
→ MCP 起動に時間がかかる。timeout を 120-300 秒に設定。

### プロセスが kill される
→ SSH セッションが切れた。`background:true` で実行し、`process action:poll` で監視。
