#!/bin/bash
# TikTok search via Apify
# Usage: ./search.sh "meditation" 20

QUERY="${1:-meditation}"
LIMIT="${2:-20}"

curl -s -X POST "https://api.apify.com/v2/acts/clockworks~tiktok-scraper/runs?token=$APIFY_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{
    \"searchQueries\": [\"$QUERY\"],
    \"resultsPerPage\": $LIMIT,
    \"shouldDownloadVideos\": false,
    \"shouldDownloadCovers\": false
  }"
