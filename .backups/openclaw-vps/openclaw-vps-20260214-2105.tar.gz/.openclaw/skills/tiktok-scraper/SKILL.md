---
name: tiktok-scraper
description: Scrape TikTok profiles and videos using Apify API. Use when you need to find trending TikTok content, analyze competitor videos, or collect hooks/captions for content research. Requires APIFY_API_TOKEN.
---

# TikTok Scraper

Scrape TikTok using Apify's clockworks/tiktok-scraper actor.

## Required ENV

```
APIFY_API_TOKEN=apify_api_xxx
```

## Usage

### Search TikTok hashtags/keywords

```bash
curl -X POST "https://api.apify.com/v2/acts/clockworks~tiktok-scraper/runs?token=$APIFY_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "searchQueries": ["meditation", "mindfulness"],
    "resultsPerPage": 20,
    "shouldDownloadVideos": false,
    "shouldDownloadCovers": false
  }'
```

### Scrape a profile

```bash
curl -X POST "https://api.apify.com/v2/acts/clockworks~tiktok-scraper/runs?token=$APIFY_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "profiles": ["oliverxthings", "larrytalks"],
    "resultsPerPage": 10,
    "shouldDownloadVideos": false
  }'
```

### Get results (after run completes)

```bash
# Get run status
curl "https://api.apify.com/v2/acts/clockworks~tiktok-scraper/runs/last?token=$APIFY_API_TOKEN"

# Get dataset items
curl "https://api.apify.com/v2/datasets/{datasetId}/items?token=$APIFY_API_TOKEN"
```

## Output Fields

- `text` - Video caption/description
- `diggCount` - Likes
- `shareCount` - Shares  
- `playCount` - Views
- `commentCount` - Comments
- `webVideoUrl` - Video URL
- `covers` - Thumbnail URLs

## Trend Hunter Integration

For trend-hunter skill, search keywords like:
- "meditation viral"
- "self improvement 30 days"
- "morning routine habits"
- "anxiety relief mindfulness"

Extract `text` field as hook candidates.
