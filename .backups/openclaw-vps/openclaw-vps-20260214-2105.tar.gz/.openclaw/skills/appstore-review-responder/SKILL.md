---
name: appstore-review-responder
description: App Store レビューを自動取得・分析・返信する。共感的でAniccaらしいトーンを維持。
---

## 🎯 ミッション

App Store のカスタマーレビューを監視し、新規レビューに対して自動的に共感的な返信を投稿する。

## ⚙️ 動作フロー

```
1. レビュー取得
   GET /v1/apps/{appId}/customerReviews
   
2. 未返信レビューをフィルタ
   - response がない OR response.state = "PENDING_PUBLISH"
   
3. Sentiment 分析
   - Positive (4-5 stars)
   - Neutral (3 stars)
   - Negative (1-2 stars)
   
4. 返信生成
   - レビュー内容を読み取る
   - Anicca のトーン（共感的・非批判的）で返信を作成
   - 具体的な感謝 + 励まし or 改善への言及
   
5. 返信投稿
   POST /v1/customerReviewResponses
   
6. Slack #ops に通知
```

## 📋 環境変数

- `ASC_KEY_ID` — App Store Connect API Key ID
- `ASC_ISSUER_ID` — Issuer ID
- `~/.keys/AuthKey_{KEY_ID}.p8` — Private Key

## 🔧 実装

### JWT 生成

```python
import jwt, time, os

key_id = os.environ['ASC_KEY_ID']
issuer_id = os.environ['ASC_ISSUER_ID']
key_path = os.path.expanduser(f'~/.keys/AuthKey_{key_id}.p8')

with open(key_path) as f:
    pk = f.read()

token = jwt.encode(
    {"iss": issuer_id, "iat": int(time.time()), "exp": int(time.time()) + 1200, "aud": "appstoreconnect-v1"},
    pk, algorithm="ES256", headers={"alg": "ES256", "kid": key_id, "typ": "JWT"}
)
```

### レビュー取得

```bash
curl -sf --max-time 30 \
  "https://api.appstoreconnect.apple.com/v1/apps/6755129214/customerReviews?limit=20&include=response" \
  -H "Authorization: Bearer {token}"
```

### 返信投稿

```bash
curl -sf --max-time 30 \
  -X POST "https://api.appstoreconnect.apple.com/v1/customerReviewResponses" \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "type": "customerReviewResponses",
      "relationships": {
        "review": {
          "data": {
            "type": "customerReviews",
            "id": "{review_id}"
          }
        }
      },
      "attributes": {
        "responseBody": "{response_text}"
      }
    }
  }'
```

## 💬 返信トーンガイドライン

### Positive (4-5 stars)

```
「{具体的な言及} 本当にありがとうございます！

あなたのような温かい言葉が、私たちの原動力です。これからも {ユーザーの目標} を全力でサポートしていきます。

引き続き、一緒に歩んでいけたら嬉しいです 🧘」
```

### Neutral (3 stars)

```
「レビューありがとうございます！

{具体的な改善点への言及}。あなたのフィードバックを真摯に受け止め、より良い体験を提供できるよう改善を続けています。

何かご意見があれば、いつでもお聞かせください 🧘」
```

### Negative (1-2 stars)

```
「貴重なフィードバックをありがとうございます。

{具体的な問題への共感}。ご期待に添えず申し訳ありません。

私たちは {改善への取り組み} に全力で取り組んでいます。もう一度チャンスをいただけたら嬉しいです 🧘」
```

## 🚨 危機対応（SAFE-T 連動）

Suffering score ≥ 0.90 の場合:
- Slack #metrics に即座に通知（@Dais メンション）
- 返信は慎重に（自動投稿前に人間確認を推奨）
- 緊急サポートへの誘導を含める

## 📊 Slack 通知フォーマット

```
📱 New App Store Review

⭐️ {rating} stars - {reviewerNickname}
Title: {title}
Body: {body}

🤖 Response sent:
{response_text}

Created: {createdDate}
Review ID: {review_id}
```

## ⏰ Cron スケジュール

1日3回チェック:
- 09:00 JST
- 15:00 JST
- 21:00 JST

```yaml
schedule:
  kind: cron
  expr: "0 9,15,21 * * *"
  tz: Asia/Tokyo

payload:
  kind: agentTurn
  message: "Check App Store reviews and respond to new ones. Use appstore-review-responder skill."
  timeoutSeconds: 300

sessionTarget: isolated

delivery:
  mode: announce
  channel: slack
  to: C091G3PKHL2  # #metrics
```

## 🧪 テスト

```bash
# 既存レビューの確認
openclaw exec "Check App Store reviews using appstore-review-responder skill"

# 手動実行
openclaw exec "Respond to App Store review {review_id} with text: {response_text}"
```

## 📝 注意事項

- App Store Connect API のレート制限: 1800 requests/hour
- 返信は1回のみ（編集・削除不可）
- 返信文字数制限: 最大 4000 文字
- レビューへの返信は review 作成から60日以内のみ可能
