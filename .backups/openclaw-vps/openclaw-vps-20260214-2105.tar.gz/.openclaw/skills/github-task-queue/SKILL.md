# GitHub Task Queue Skill

Anicca が GitHub Issues をタスクキューとして自動処理するスキル。

## 仕組み

```
[GitHub Issues]
  │
  ├── Open + label:anicca-task ← タスクを投げ込む
  │     ↓
  │   🧘 Anicca が自動でタスク実行
  │     ↓
  └── Closed ← 完了したら自動でクローズ
```

## 使い方

1. **タスク追加**: GitHub Issue を作成し、`anicca-task` ラベルを付ける
2. **自動実行**: Anicca が 5分ごとにチェックして実行
3. **完了報告**: 結果をコメントして Issue をクローズ

## コマンド

### タスクをチェック
```bash
gh issue list --repo Daisuke134/anicca.ai --label "anicca-task" --state open --json number,title,body
```

### タスク完了
```bash
gh issue close <number> --repo Daisuke134/anicca.ai --comment "✅ 完了しました\n\n<結果>"
```

## ラベル

- `anicca-task`: Anicca が処理するタスク
- `in-progress`: 処理中（オプション）
- `blocked`: ブロック中（人間の介入が必要）

## 実行フロー

1. `gh issue list` で `anicca-task` ラベルの Open Issues を取得
2. 各 Issue の `body` を読んでタスク内容を理解
3. タスクを実行
4. 結果を Issue にコメント
5. Issue をクローズ

## 注意

- 1回の実行で最大 3 タスクまで処理（レート制限対策）
- エラー時は `blocked` ラベルを付けて人間に報告
- 危険なタスク（削除、本番デプロイ等）は確認を求める
