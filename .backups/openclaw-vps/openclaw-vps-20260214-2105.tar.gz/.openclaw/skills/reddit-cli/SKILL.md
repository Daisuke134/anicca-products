---
name: reddit-cli
description: Reddit CLI using reddapi.dev API. Semantic search, trends, and subreddit discovery.
---

# Reddit CLI (reddapi.dev)

Search and analyze Reddit using reddapi.dev's API.

## Required ENV

```
REDDAPI_API_KEY=rdi_xxx
```

Get your API key at: https://reddapi.dev

## Usage

### Semantic Search

Natural language search across millions of Reddit posts and comments.

```bash
curl -X POST "https://reddapi.dev/api/v1/search/semantic" \
  -H "Authorization: Bearer $REDDAPI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"query": "best productivity tools for remote teams", "limit": 100}'
```

### Find Pain Points

```bash
curl -X POST "https://reddapi.dev/api/v1/search/semantic" \
  -H "Authorization: Bearer $REDDAPI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"query": "frustrations with meditation apps", "limit": 100}'
```

### Trends API

Discover trending topics with engagement metrics.

```bash
curl "https://reddapi.dev/api/v1/trends" \
  -H "Authorization: Bearer $REDDAPI_API_KEY"
```

Response includes:
- `post_count`: Number of posts
- `total_upvotes`: Engagement score
- `avg_sentiment`: Sentiment analysis (-1 to 1)
- `trending_keywords`: Top keywords
- `growth_rate`: Trend momentum

### Subreddit Discovery

```bash
# List popular subreddits
curl "https://reddapi.dev/api/subreddits?limit=100" \
  -H "Authorization: Bearer $REDDAPI_API_KEY"

# Get specific subreddit info
curl "https://reddapi.dev/api/subreddits/meditation" \
  -H "Authorization: Bearer $REDDAPI_API_KEY"
```

## Response Format

### Search Results
```json
{
  "success": true,
  "results": [
    {
      "id": "post123",
      "title": "User post title",
      "selftext": "Post content...",
      "subreddit": "r/somesub",
      "score": 1234,
      "num_comments": 89,
      "created_utc": "2024-01-15T10:30:00Z"
    }
  ],
  "total": 15000
}
```

### Trends Response
```json
{
  "success": true,
  "data": {
    "trends": [
      {
        "topic": "AI regulation",
        "post_count": 1247,
        "total_upvotes": 45632,
        "avg_sentiment": 0.42,
        "growth_rate": 245.3
      }
    ]
  }
}
```

## Trend Hunter Integration

Target subreddits for hook research:
- r/meditation
- r/getdisciplined
- r/selfimprovement
- r/Anxiety
- r/habits
- r/productivity

Search for:
- High-engagement posts with relatable hooks
- User frustrations and pain points
- Viral content patterns
