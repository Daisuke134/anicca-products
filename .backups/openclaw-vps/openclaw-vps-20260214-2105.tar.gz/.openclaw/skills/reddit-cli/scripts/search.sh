#!/bin/bash
# Reddit search via REDDAPI
# Usage: ./search.sh "meditation tips" 25

QUERY="${1:-meditation}"
LIMIT="${2:-25}"

curl -s "https://api.reddapi.com/v1/search?q=$(echo $QUERY | sed 's/ /+/g')&sort=relevance&limit=$LIMIT" \
  -H "Authorization: Bearer $REDDAPI_API_KEY"
