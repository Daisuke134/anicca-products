#!/usr/bin/env bash
# Start OpenClaw gateway (doc default: no OPENCLAW_STATE_DIR override)
exec /opt/homebrew/bin/openclaw gateway "$@"
