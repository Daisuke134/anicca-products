"""Passive observer package."""
